"""
    Wrapper modules for CATIA bodies.
"""
