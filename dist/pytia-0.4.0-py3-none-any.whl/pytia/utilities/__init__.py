"""
    Utility modules for CATIA.
"""
