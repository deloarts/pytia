"""
    Helper functions for the CATIA framework.
"""
