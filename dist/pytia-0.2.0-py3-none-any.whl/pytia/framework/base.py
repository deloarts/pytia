class Base:
    """
    Base class for the framework.
    """

    def __init__(self):
        pass
