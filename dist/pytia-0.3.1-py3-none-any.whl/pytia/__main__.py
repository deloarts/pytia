#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
    Application entry point.
"""

from pytia import main

main.main()
