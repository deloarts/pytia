"""
    Wrapper modules for the CATIA framework.
"""
