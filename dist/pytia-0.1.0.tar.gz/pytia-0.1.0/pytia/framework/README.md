# Framework

This framework is based on the work of <https://github.com/evereux>, see [pycatia](https://github.com/evereux/pycatia) ([license](https://github.com/evereux/pycatia/blob/master/LICENSE.txt)).

The documentation of this framework can be found inside the [**V5automation.chm**](/assets/V5Automation.chm) help file.

> ⚠️ Note: Due to some changes this framework is not or only partly compatible with the original codebase!
