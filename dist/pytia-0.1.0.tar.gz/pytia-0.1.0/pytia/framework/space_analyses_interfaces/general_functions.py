def create_measurable(spa_workbench, com_reference):
    return spa_workbench.GetMeasurable(com_reference)
