"""
    Wrapper modules for CATIA documents.
"""
