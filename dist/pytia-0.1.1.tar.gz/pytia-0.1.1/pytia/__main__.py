#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""

"""

from pytia import main

main.main()
